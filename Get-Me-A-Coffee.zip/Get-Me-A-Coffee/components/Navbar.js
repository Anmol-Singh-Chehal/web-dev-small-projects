import React from 'react'
import Link from '@/app/node_modules/next/link'
import { auth } from '@/auth';

const Navbar = async () => {
  let username = "anmol";
  const session = await auth();
  return (
    <nav className=' flex items-center justify-between'>
      <p className='font-semibold text-2xl text-white underline'>Practice App</p>
      <div className='text-white flex gap-3 text-sm font-semibold'>
        <Link className='hover:underline' href="/">Home</Link>
        <Link className='hover:underline' href="/about">About</Link>
        
        {session ? 
          <Link className='hover:underline' href={`${session.user.name}`}>Your Page</Link>:
        <Link className='hover:underline' href="/sign-in">Sign In</Link>}
      </div>
    </nav>
  )
}

export default Navbar
