import { SessionProvider } from "@/app/node_modules/next-auth/react";

export default function Providers({children}) {
    return <SessionProvider>{children}</SessionProvider>
}