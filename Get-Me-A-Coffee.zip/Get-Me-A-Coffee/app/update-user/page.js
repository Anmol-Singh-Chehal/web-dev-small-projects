"use client";
import { useRef, useState, useEffect } from 'react';
import React from 'react'
import { fetchUser } from '../actions/userActions';
import { useSession } from 'next-auth/react';
import { updateUser } from '../actions/userActions';
import { useRouter } from 'next/navigation';

const UpdateUser = () => {
    const router = useRouter();
    const session = useSession();
    const sumbitRef = useRef();
    
    const [form, setForm] = useState({
        username: "",
        profilePicture: "",
        description: "",
        razorpayId: "",
        razorpaySecret: "",
        email: ""
    });

    const handleUpdate = async () => {
        const {status} = await updateUser(form.email, form);
        if(status){
            setForm({
                username: "",
                profilePicture: "",
                description: "",
                razorpayId: "",
                razorpaySecret: "",
                email: ""
            })
            router.push(`/${session.data.user.name}`);
            console.log(status);
        }
    }

    const setUserData = async () => {
        if(session.status === "authenticated"){
            const user = await fetchUser(session.data.user.email);
            if(user){
                setForm({
                    ...form,
                    username: user.name,
                    profilePicture:user.profilePicture,
                    email: session.data.user.email,
                    description: user.description || "",
                    razorpayId: user.razorpayId || "",
                    razorpaySecret: user.razorpaySecret || "",
                });
            }
        }
    }

    useEffect(()=>{
        if(form.razorpayId.length < 4 || form.razorpaySecret.length < 5 || form.username.length < 2 || form.description.length < 10){
            sumbitRef.current.disabled = true;
            sumbitRef.current.style.backgroundColor = "#1e2939";
        }
        else{
            sumbitRef.current.disabled = false;
            sumbitRef.current.style.backgroundColor = "";
        }
    }, [form]);

    useEffect(()=>{
        setUserData();
    }, [session]);
    


    const handleFileInput = (event) => {
        const file = event.target.files[0];
        const fileTypes = ["image/jpeg", "image/png", "image/jpg"];

        if (file &&
            (file.size / (1024 * 1024)).toFixed(2) <= 5 &&
            (fileTypes.includes(file.type))) {

            const reader = new FileReader();
            reader.onload = (event) => {
                const base64Image = event.target.result;
                console.log("Success");
                setForm({ ...form, profilePicture: base64Image });
            }
            reader.readAsDataURL(file);
        }
        else {
            console.log("Failed");
        }
    }
    
    return (
        <div className='mt-8 flex flex-col items-center'>

            <div className="flex items-center justify-center min-w-[500px] max-w-[600px]">
                <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-52 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-gray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        {form.profilePicture ? <div className='w-30 h-30 overflow-hidden rounded-full'><img src={form.profilePicture} alt="profile picture" className='object-contain' /></div> :
                            <>
                                <svg className="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
                                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2" />
                                </svg>
                                <p className="mb-2 text-sm text-gray-500 dark:text-gray-400"><span className="font-semibold">Click to upload Profile Picture</span> or drag and drop</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG or JPEG (MAX LIMIT 5MB)</p>
                            </>}
                    </div>
                    <input id="dropzone-file" type="file" className="hidden" onChange={(event) => handleFileInput(event)} />
                </label>
            </div>

            <div className="mx-auto mt-4 min-w-[450px] flex flex-col">

                <div className="relative z-0 w-full mb-5 group">
                    <input type="text" name="floating_description" id="floating_password" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " value={form.description} onChange={(event)=>setForm({...form, description:event.target.value})} required />
                    <label htmlFor="floating_description" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Description</label>
                </div>

                <div className="relative z-0 w-full mb-5 group">
                    <input type="text" name="floating_name" id="floating_name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " value={form.username} onChange={(event)=>setForm({...form, username:event.target.value})} required />
                    <label htmlFor="floating_name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6" >Username</label>
                </div>

                <div className="relative z-0 w-full mb-5 group">
                    <input type="text" name="floating_id" id="floating_id" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " value={form.razorpayId} onChange={(event)=>setForm({...form, razorpayId:event.target.value})} required />
                    <label htmlFor="floating_id" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6" >Razorpay Id</label>
                </div>

                <div className="relative z-0 w-full mb-5 group">
                    <input type="text" name="floating_secret" id="floating_secret" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " value={form.razorpaySecret} onChange={(event)=>setForm({...form, razorpaySecret:event.target.value})} required />
                    <label htmlFor="floating_secret" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6" >Razorpay Secret</label>
                </div>

                <button type="submit" ref={sumbitRef} className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 cursor-pointer" onClick={() => handleUpdate()}>Update</button>
            </div>

        </div>
    )
}

export default UpdateUser



