"use server"
import { validatePaymentVerification } from "razorpay/dist/utils/razorpay-utils";
import { NextResponse } from "next/server";
import User from "@/app/lib/models/User";
import connectDB from "@/app/lib/connectDB";
import Payment from "@/app/lib/models/Payments";

export const POST = async (req) => {
    let body = await req.formData()
    body = Object.fromEntries(body);

    let payment = validatePaymentVerification({"order_id": body.razorpay_order_id, "payment_id": body.razorpay_payment_id}, body.razorpay_signature, process.env.RAZORPAY_SECRET);

    await connectDB();
    const foundPayment = await Payment.findOne(
        {oid: body.razorpay_order_id}
    );
    if(!foundPayment){
        console.log("Order id didn't found.");
    } else {
        console.log("Order id found.");
        await Payment.updateOne(
            {oid: body.razorpay_order_id},
            {isDone: true, madeAt: Date.now()}
        );
    }

    if(payment){
        return NextResponse.redirect(`${process.env.NEXT_PUBLIC_URL}/anmol?paymentdone=true`);
    }
    else{
        return NextResponse.json({success: false, message:"Payment Verification Failed"});
    }

}