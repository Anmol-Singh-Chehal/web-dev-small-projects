import React from 'react'
import { auth } from '@/auth';

const Home = async () => {
  const session = await auth();
  
  return (
    <div>
      <p className='text-white flex justify-center items-center pt-20 text-2xl font-semibold'>This is Home Page.</p>
      <p className='text-white flex justify-center items-center text-2xl font-semibold'>{session ? "Your are signed In." : "Sign In Please."}</p>
    </div>
  )
}

export default Home
