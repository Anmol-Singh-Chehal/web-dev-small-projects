"use client";
import React from 'react'
import githubImage from "../assets/github.png";
import googleImage from "../assets/google.png";
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';

const SignIn = () => {
  const router = useRouter();
  const handleSignIn = async () => {
   const result = await signIn("github");
  }
  return (
    <div className='flex flex-col gap-2 py-20' >
      <button className='flex gap-2 items-center ring-1 bg-white px-2 rounded-lg pr-3 hover:bg-gray-500 focus:ring-4 self-center' onClick={handleSignIn}>
        <img className="w-12" src={githubImage.src} alt="GitHub Logo" />
        <p className='font-semibold'>Continue With GitHub</p>
      </button>

      <button className='flex gap-2 items-center ring-1 bg-white px-2 rounded-lg pr-3 hover:bg-gray-500 focus:ring-4 self-center'>
        <img className="w-12" src={googleImage.src} alt="Google Logo" />
        <p className='font-semibold'>Continue With Google</p>
      </button>
    </div>
  )
}

export default SignIn
