"use client";
import React from 'react'
import Link from 'next/link'
import {signOut} from "next-auth/react"
import { useRouter } from 'next/navigation';
import { useState, useRef, useEffect } from 'react';
import {fetchUser} from '../actions/userActions';
import { getOrderId } from '../actions/userActions';
import { useSession } from 'next-auth/react';
import { fetchPayments } from '../actions/userActions';

const UserName = () => {
  const router = useRouter();
  const session = useSession();

  const [form, setForm] = useState({name: "", amount:"", message:""});
  const payRef = useRef({});
  const [payments, setPayments] = useState([]);
  const [userData, setUserData] = useState({
    name:"",
    email: "",
    picture: "",
    description: "",
  });

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    document.body.appendChild(script);
  }, []);

  
  const handleSignOut = async () => {
    await signOut(); 
    router.push("/");
  }

  const fetchUserData = async () => {
      try {
        const user = await fetchUser(session.data.user.email);
        
        if (user) {
          setUserData({
            name: user.name || "",
            email: user.email || "",
            picture: user.profilePicture || "",
            description: user.description || "",
          });
        }
        else{
          console.log("User is null.");
        }
      } catch (error) {
        console.error("Error fetching user:", error);
      }
  };

  const setPaymentsData = async () => {
    const paymentsArray = await fetchPayments(userData.name);
    if(paymentsArray){
      console.log("Payments fetch successfull.");
      console.log(paymentsArray);
      setPayments(paymentsArray);
    } else {
      console.log("Payments fetch failed.");
    }
  }

  useEffect(() => {
    if (session.status === "authenticated" && session?.data?.user?.email) {
      fetchUserData();
    }
  }, [session?.data?.user?.email]);

  useEffect(()=>{
    setPaymentsData();
  }, [userData]);

  const buttons = ["pay", "pay-10", "pay-30", "pay-50"];
  useEffect(()=>{
    if(parseInt(form.amount) < 5 || isNaN(form.amount) || form.message.length < 3 || form.name.length < 3 || form.amount === ""){
      for(let i=0; i<buttons.length; i++){
        payRef.current[buttons[i]].disabled = true;
        payRef.current[buttons[i]].classList.remove(
          "bg-gradient-to-br", 
          "from-purple-600", 
          "to-blue-500",
          "hover:bg-gradient-to-bl"
        )
        payRef.current[buttons[i]].style.backgroundColor = "#838383";
      }
    }
    else{
      for(let i=0; i<buttons.length; i++){
        payRef.current[buttons[i]].disabled = false;
        payRef.current[buttons[i]].classList.add(
          "bg-gradient-to-br", 
          "from-purple-600", 
          "to-blue-500",
          "hover:bg-gradient-to-bl"
        )
        payRef.current[buttons[i]].style.backgroundColor = "";
      }
    }
  }, [form]);

  const handlePayment = async (amount) =>{
    const order = await getOrderId(amount, userData.name, form);
    
    const options = {
      "key": process.env.NEXT_PUBLIC_RAZORPAY_ID, // Enter the Key ID generated from the Dashboard
      "amount": amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
      "currency": "INR",
      "name": "Get Me A Coffee", //your business name
      "description": "Test Transaction",
      "image": "https://example.com/your_logo",
      "order_id": order.id, //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
      "callback_url": `${process.env.NEXT_PUBLIC_URL}/api/razorpay`,
      "prefill": { //We recommend using the prefill parameter to auto-fill customer's contact information especially their phone number
          "name": "Gaurav Kumar", //your customer's name
          "email": "gaurav.kumar@example.com",
          "contact": "9000090000" //Provide the customer's phone number for better conversion rates 
      },
      "notes": {
          "address": "Razorpay Corporate Office"
      },
      "theme": {
          "color": "#3399cc"
      }
    };
    
    const rzp1 = new window.Razorpay(options);
    rzp1.open();
}
  

  return (
    <div className='flex flex-col gap-8 pt-5  items-center'>
      <div className='text-white text-lg font-semibold flex flex-col items-center gap-2'>
        <div className='w-30 h-30 bg-white overflow-clip rounded-full'>
          <img className='object-cover' src={userData.picture ? userData.picture : null} alt="user image"/>
          hello
        </div>
        <p>@{userData.name}</p>

       <div className='flex gap-2'>
        <Link className='text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2 text-center mb-2' href="/update-user">Update Profile</Link>

        <button className='text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2 text-center mb-2' onClick={handleSignOut}>Sign Out</button>
       </div>

        <p className='text-sm w-[400px] text-center'>{userData.description}</p>
      </div>

      <div className='bg-gradient-to-r from-[#0f172a] to-[#334155] rounded-lg flex flex-col py-2 px-4 gap-2 text-white min-w-[450px] min-h-[250px]'>
        <p className='text-md font-semibold underline'>Top Donators: </p>
        <ul className='flex flex-col text-sm font-semibold '>
          {
            payments && payments.map((payment)=>{
              return <li key={payment.id}>{payment.from} Donated {payment.amount} with a message "{payment.message}"</li>
            })
          }
        </ul>
      </div>

      <div className='bg-gradient-to-r from-[#0f172a] to-[#334155] rounded-lg flex flex-col p-2 gap-2 mb-10'>
        <input type="text" className='text-white bg-slate-600 p-2 rounded-lg outline-0 focus:outline-2 focus:outline-blue-600 font-semibold min-w-[450px]' placeholder='Enter Name here...' value={form.name} onChange={(event)=>setForm({...form, name:event.target.value})} required/>
        <input type="text" className='text-white bg-slate-600 p-2 rounded-lg outline-0 focus:outline-2 focus:outline-blue-600 font-semibold min-w-[450px]' placeholder='Enter Amount here...' value={form.amount} onChange={(event)=>setForm({...form, amount:event.target.value})} required/>
        <input type="text" className='text-white bg-slate-600 p-2 rounded-lg outline-0 font-semibold focus:outline-2 focus:outline-blue-600 min-w-[450px]' placeholder="Enter a Message here..." value={form.message} onChange={(event)=>setForm({...form, message:event.target.value})} required/>

        <button type="button" className="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mb-2" ref={event => payRef.current["pay"] = event}  onClick={()=>handlePayment(parseInt(form.amount)*100)}>Pay</button>

        <div className='flex gap-2 items-center'>
          <button type="button" className="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mb-2" ref={event => payRef.current["pay-10"] = event}>Pay 10₹</button>

          <button type="button" className="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mb-2" ref={event => payRef.current["pay-30"] = event}>Pay 30₹</button>

          <button type="button" className="text-white bg-gradient-to-br from-purple-600 to-blue-500 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center mb-2" ref={event => payRef.current["pay-50"] = event}>Pay 50₹</button>
        </div>
      </div>
    </div>
  )
}

export default UserName;
