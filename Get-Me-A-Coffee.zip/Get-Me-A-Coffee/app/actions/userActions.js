"use server";
import User from "../lib/models/User";
import Razorpay from "razorpay";
import Payment from "../lib/models/Payments";
import connectDB from "../lib/connectDB";

export const fetchUser = async (email) => {
    await connectDB();
    let user = await User.findOne({email: email});
    if(!user){
        return null;
    }
    user = user.toObject({ flattenObjectIds: true });
    return user;
}

export const getOrderId = async (amount, username, form) => {
    let instance = new Razorpay({ 
        key_id: process.env.NEXT_PUBLIC_RAZORPAY_ID,
        key_secret: process.env.RAZORPAY_SECRET,
    });
    let options = {
        amount: amount,
        currency: "INR",
    }
    let order = await instance.orders.create(options);

    await connectDB();
    const payment = await Payment.create({
        from: form.name,
        to: username,
        oid: order.id,
        message: form.message,
        amount: form.amount,
        madeAt: "",
        isDone: false,  
    });
    
    return order;
}

export const updateUser = async (email, form) => {
    await connectDB();
    const user = await User.updateOne(
        {email: email},
        {
            name: form.username,
            profilePicture: form.profilePicture,
            description: form.description,
            razorpayId: form.razorpayId,
            razorpaySecret: form.razorpaySecret,
        }
    );
    if(user){
        return {status: "User updated successfully"};
    } else {
        return {status: "User doesn't exist."};
    }
}

export const fetchPayments = async (username) => {
  try {
    await connectDB();
    const payments = await Payment.find({
      to: username,
      isDone: true,
    }).sort({ amount: -1 }).limit(10).lean();

    const filteredPayments = payments.map(({ _id, ...rest }) => {
      return {
        id: _id.toString(), 
        ...rest,
      };
    });

    return filteredPayments;

  } catch (error) {
    console.error("Error fetching payments:", error);
    return []; // return an empty array or handle the error as needed
  }
};
