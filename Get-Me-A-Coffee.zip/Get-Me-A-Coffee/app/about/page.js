import React from 'react'

const About = () => {
  return (
    <div className='text-white flex justify-center items-center py-20 text-2xl font-semibold'>
      This is About Page.
    </div>
  )
}

export default About
