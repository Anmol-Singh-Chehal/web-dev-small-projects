import NextAuth from "next-auth";
import GitHub from "next-auth/providers/github";
import connectDB from "./app/lib/connectDB";
import User from "./app/lib/models/User";
import fs from "fs";
import path from "path";

const imagePath = path.join(process.cwd(), "app/assets/user.png");
const imageBuffer = fs.readFileSync(imagePath);
const defaultImage = `data:image/png;base64,${imageBuffer.toString("base64")}`;

export const authOptions = NextAuth({
    providers: [
        GitHub({
            clientId: process.env.GITHUB_ID,
            clientSecret: process.env.GITHUB_SECRET,
        }),
    ],
    secret: process.env.AUTH_SECRET,
    callbacks: {
        async signIn({user, profile, account}){
            if(account.provider === "github"){
                try{
                    await connectDB();
                    const dbUser = await User.findOne({email: user.email});
                    if(!dbUser){
                        const newDBUser = await User.create({
                            name: user.name,
                            email: user.email,
                            profilePicture:defaultImage,
                        });
                    }
                } catch(error){
                    console.log(error);
                    return false;
                }
                return true;
            }
        },

        async redirect({ url, baseUrl }) {
            // Redirect to home after auth
            return url.startsWith(baseUrl) ? "/" : url;
        }
    }
});

export const {handlers, auth, signIn, signOut} = authOptions;
