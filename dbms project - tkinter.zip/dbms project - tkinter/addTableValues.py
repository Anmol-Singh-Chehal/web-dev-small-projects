import sqlite3
import random
from datetime import datetime, timedelta

connect = sqlite3.connect("zooDatabase.db")
query = connect.cursor()

def random_date(start_date, end_date):
    return start_date + timedelta(days=random.randint(0, (end_date - start_date).days))

# Data Arrays
animalRecords = [
    (i, f'Animal_{i}', random.choice(['Lion', 'Tiger', 'Elephant', 'Giraffe', 'Panda']),
     random.choice(['male', 'female', 'unknown']),
     random_date(datetime(2015, 1, 1), datetime(2023, 12, 31)).date(),
     random.choice(['Healthy', 'Sick', 'Under Observation']),
     random.choice(['Carnivore', 'Herbivore', 'Omnivore']),
     random_date(datetime(2022, 1, 1), datetime(2024, 1, 1)).date(),
     random.randint(1, 28),
     random_date(datetime(2023, 1, 1), datetime(2024, 1, 1)).date(),
     random.randint(1, 30))
    for i in range(1, 31)
]

eventRecords = [
    (i, f'Event_{i}', random.choice(['Education', 'Entertainment', 'Conservation']),
     random_date(datetime(2023, 1, 1), datetime(2025, 12, 31)).date(),
     f'Location_{i}',
     random.randint(1, 28))
    for i in range(1, 11)
]

inventoryRecords = [
    (i, f'Item_{i}', random.choice(['Food', 'Medical', 'Equipment', 'Enrichment']),
     random.randint(1, 100),
     f'Supplier_{random.randint(1, 10)}',
     random_date(datetime(2024, 1, 1), datetime(2026, 1, 1)).date())
    for i in range(1, 31)
]

reportRecords = [
    (i, random.choice(['Animal Health', 'Incident', 'Maintenance']),
     random.randint(1, 28),
     random_date(datetime(2023, 1, 1), datetime(2024, 1, 1)).date(),
     f'Report details {i}')
    for i in range(1, 15)
]

staffRecords = [
    (i, f'FirstName_{i}', f'LastName_{i}',
     random.choice(['Keeper', 'Vet', 'Manager', 'Guide', 'Maintenance']),
     random_date(datetime(2018, 1, 1), datetime(2023, 12, 31)).date(),
     round(random.uniform(20000, 80000), 2),
     f'Contact_{i}',
     random_date(datetime(1985, 1, 1), datetime(2000, 12, 31)).date(),
     random.randint(1, 30))
    for i in range(1, 29)
]

visitorRecords = [
    (i, f'Visitor_{i}', f'Contact_{i}',
     random_date(datetime(2023, 1, 1), datetime(2025, 12, 31)).date(),
     random.choice(['Adult', 'Child', 'Senior']),
     round(random.uniform(100, 500), 2))
    for i in range(1, 21)
]

enclosureRecords = [
    (i, f'Enclosure_{i}', random.choice(['Small', 'Medium', 'Large']),
     random.choice(['15-25C', '25-35C', '5-15C']))
    for i in range(1, 31)
]


def addAnimals(data):
    query.execute('''
        create table if not exists animalRecords(
            animalId int primary key,
            name text,
            species text,
            gender text check (gender in ("male", "female", "unknown")),
            dateOfBirth date,
            healthStatus text,
            diet text,
            arrivalDate date,
            keeperId int,
            lastCheckupDate date,
            enclosureId int,
            foreign key (enclosureId) references enclosureRecords(enclosureId),
            foreign key (keeperId) references staffRecords(staffId)
        )
    ''')
    for record in data:
        query.execute('''
            insert into animalRecords values(?,?,?,?,?,?,?,?,?,?,?)
        ''', record)

def addEvents(data):
    query.execute('''
        create table if not exists eventRecords(
            eventId int primary key,
            eventName text not null,
            eventType text,
            eventDate date not null,
            eventLocation text not null,
            staffInChargeId int,
            foreign key (staffInChargeId) references staffRecords(staffId)
        )
    ''')
    for record in data:
        query.execute('''
            insert into eventRecords values(?,?,?,?,?,?)
        ''', record)

def addInventory(data):
    query.execute('''
        create table if not exists inventoryRecords(
            itemId int primary key,
            itemName text,
            category text not null,
            quantity int,
            supplierName text,
            expiryDate date
        )
    ''')
    for record in data:
        query.execute('''
            insert into inventoryRecords values(?,?,?,?,?,?)
        ''', record)

def addReports(data):
    query.execute('''
        create table if not exists reportRecords(
            reportId int primary key,
            reportType text,
            generatedBy int,
            generatedDate date,
            reportDetails text,
            foreign key (generatedBy) references staffRecords(staffId)
        )
    ''')
    for record in data:
        query.execute('''
            insert into reportRecords values(?,?,?,?,?)
        ''', record)

def addStaff(data):
    query.execute('''
        create table if not exists staffRecords(
            staffId int primary key,
            firstName text,
            lastName text,
            role text,
            hire date,
            salary decimal,
            contactInfo text,
            dateOfBirth date,
            assignedEnclosure int,
            foreign key (assignedEnclosure) references enclosureRecords(enclosureId)
        )
    ''')
    for record in data:
        query.execute('''
            insert into staffRecords values(?,?,?,?,?,?,?,?,?)
        ''', record)

def addVisitor(data):
    query.execute('''
        create table if not exists visitorRecords(
            visitorId int primary key,
            fullName text,
            contactInfo text,
            visitDate date,
            ticketType text,
            amountPaid decimal
        )
    ''')
    for record in data:
        query.execute('''
            insert into visitorRecords values(?,?,?,?,?,?)
        ''', record)

def addEnclosure(data):
    query.execute('''
        create table if not exists enclosureRecords(
            enclosureId int primary key,
            name text,
            size text,
            temperatureRange text
        )
    ''')
    for record in data:
        query.execute('''
            insert into enclosureRecords values(?,?,?,?)
        ''', record)

addAnimals(animalRecords)
addEvents(eventRecords)
addInventory(inventoryRecords)
addReports(reportRecords)
addStaff(staffRecords)
addVisitor(visitorRecords)
addEnclosure(enclosureRecords)
connect.commit()
