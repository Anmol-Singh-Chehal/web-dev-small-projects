from tkinter import *
import subprocess

window = Tk()
window.title("ZOO MANAGEMENT SYSTEM - MAIN WINDOW")

window.config(bg="#1e1e2e")
window.configure(bg="#1e1e2e")
window.geometry("800x500")
mainText = Label(window, text="ZOO MANAGEMENT SYSTEM", font=("Consolas", 28, "bold"), bg="#1e1e2e", fg="#c678dd")
mainText.pack(pady=5)

mainFrame = Frame(window, bg="#1e1e2e")
mainFrame.pack(padx=10, pady=5, fill="both")

button = []
info = ["Animal Records", "Staff Management", "Visitor Management",
        "Inventory Management", "Events Management", "Reporting and Analytics", "Enclosure Management"]
paths = ["animalRecords/input.py", "animalRecords/modify.py", "animalRecords/output.py",
         "staffRecords/input.py", "staffRecords/modify.py", "staffRecords/output.py",
         "visitorRecords/input.py", "visitorRecords/modify.py", "visitorRecords/output.py",
         "inventoryRecords/input.py", "inventoryRecords/modify.py", "inventoryRecords/output.py",
         "eventRecords/input.py", "eventRecords/modify.py", "eventRecords/output.py",
         "reportRecords/input.py", "reportRecords/modify.py", "reportRecords/output.py",
         "enclosureRecords/input.py", "enclosureRecords/modify.py", "enclosureRecords/output.py"]

def onClick(index):
    subprocess.Popen(["python", paths[index]])

index = 0
buttonIndex = 0
for i in range(3):
    rowFrame = Frame(mainFrame, bg="#1e1e2e")
    rowFrame.pack(side="top", fill="x")

    for j in range(2):
        frame = Frame(rowFrame, width=370, height=95, bg="#282c34", borderwidth=2, relief="solid")  
        frame.pack(side="left", padx=10, pady=5)
        frame.pack_propagate(False)

        label = Label(frame, text=info[index], bg="#282c34", fg="#61afef", font=("Consolas", 16, "bold"))
        label.place(relx=0.5, rely=0.3, anchor="center")
        index += 1

        buttonFrame = Frame(frame, bg="#282c34")
        buttonFrame.place(relx=0.5, rely=0.7, anchor="center")

        button.append(Button(buttonFrame, text="Input", command=lambda i=buttonIndex: onClick(i),
                              width=10, bg="#3e4451", fg="#98c379", font=("Consolas", 12, "bold"), bd=2,
                              relief="raised", activebackground="#56b6c2"))
        button[buttonIndex].pack(side="left", padx=5)
        buttonIndex += 1

        button.append(Button(buttonFrame, text="Modify", command=lambda i=buttonIndex: onClick(i),
                              width=10, bg="#3e4451", fg="#e5c07b", font=("Consolas", 12, "bold"), bd=2,
                              relief="raised", activebackground="#c678dd"))
        button[buttonIndex].pack(side="left", padx=5)
        buttonIndex += 1

        button.append(Button(buttonFrame, text="Output", command=lambda i=buttonIndex: onClick(i),
                              width=10, bg="#3e4451", fg="#e06c75", font=("Consolas", 12, "bold"), bd=2,
                              relief="raised", activebackground="#61afef"))
        button[buttonIndex].pack(side="left", padx=5)
        buttonIndex += 1

frame = Frame(window, width=370, height=95, bg="#282c34", borderwidth=2, relief="solid")
frame.pack(pady=1)
frame.pack_propagate(False)

label = Label(frame, text=info[index], bg="#282c34", fg="#61afef", font=("Consolas", 16, "bold"))
label.place(relx=0.5, rely=0.3, anchor="center")

buttonFrame = Frame(frame, bg="#282c34")
buttonFrame.place(relx=0.5, rely=0.7, anchor="center")

button.append(Button(buttonFrame, text="Input", command=lambda i=buttonIndex: onClick(i),
                      width=10, bg="#3e4451", fg="#98c379", font=("Consolas", 12, "bold"), bd=2,
                      relief="raised", activebackground="#56b6c2"))
button[buttonIndex].pack(side="left", padx=5)
buttonIndex += 1

button.append(Button(buttonFrame, text="Modify", command=lambda i=buttonIndex: onClick(i),
                      width=10, bg="#3e4451", fg="#e5c07b", font=("Consolas", 12, "bold"), bd=2,
                      relief="raised", activebackground="#c678dd"))
button[buttonIndex].pack(side="left", padx=5)
buttonIndex += 1

button.append(Button(buttonFrame, text="Output", command=lambda i=buttonIndex: onClick(i),
                      width=10, bg="#3e4451", fg="#e06c75", font=("Consolas", 12, "bold"), bd=2,
                      relief="raised", activebackground="#61afef"))
button[buttonIndex].pack(side="left", padx=5)
buttonIndex += 1

window.mainloop()
