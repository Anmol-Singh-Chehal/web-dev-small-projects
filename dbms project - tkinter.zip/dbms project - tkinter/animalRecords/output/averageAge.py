from tkinter import *
import sqlite3

window = Tk()
window.title("ANIMAL RECORDS - OUTPUT (Average Age by Species)")
window.geometry("1000x500")
window.config(bg="#1e1e2e")

connect = sqlite3.connect("F:/my/be coding/dbms project - tkinter/zooDatabase.db")
query = connect.cursor()

container = Frame(window, bg="#1e1e2e")
container.pack(padx=5, pady=5, fill="both", expand=True)

canvas = Canvas(container, bg="#1e1e2e", height=400, highlightthickness=0)
scrollbar = Scrollbar(container, orient="vertical", command=canvas.yview)

scrollableFrame = Frame(canvas, bg="#1e1e2e")

canvas.create_window((0, 0), window=scrollableFrame, anchor="nw")

canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

def update_scroll_region(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

scrollableFrame.bind("<Configure>", update_scroll_region)

# SQL Query to calculate average age of each species
query.execute("""
    SELECT species, CAST(AVG((julianday('now') - julianday(dateOfBirth)) / 365) AS INT)
    FROM animalRecords
    GROUP BY species
""")
data = query.fetchall()

headers = ["Species", "Average Age"]
for col, header in enumerate(headers):
    label = Label(scrollableFrame, text=header, bg="#3e4451", fg="#61afef", font=("Consolas", 12, "bold"), padx=5, pady=5, borderwidth=1, relief="solid")
    label.grid(row=0, column=col, sticky="nsew")

for i, row in enumerate(data):
    for j, value in enumerate(row):
        label = Label(scrollableFrame, text=value, bg="#282c34", fg="#abb2bf", font=("Consolas", 12), padx=5, pady=5, borderwidth=1, relief="solid")
        label.grid(row=i + 1, column=j, sticky="nsew")

for i in range(len(headers)):
    scrollableFrame.grid_columnconfigure(i, weight=1)

connect.commit()
connect.close()

window.mainloop()
