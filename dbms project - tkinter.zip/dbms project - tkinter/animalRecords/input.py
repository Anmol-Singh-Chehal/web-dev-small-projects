from tkinter import *
import sqlite3

window = Tk()
window.title("ANIMAL RECORDS - INPUT")
window.geometry("800x530")
window.config(bg="#1e1e2e")

connect = sqlite3.connect("F:/my/be coding/dbms project - tkinter/zooDatabase.db")
query = connect.cursor()

entry = []
labelText = ["Enter id here:",
             "Enter name here:",
             "Enter species here:",
             "Enter gender here:",
             "Enter date of birth here:",
             "Enter Health status here:",
             "Enter diet here:",
             "Enter arrival date here:",
             "Enter keeper id here:",
             "Enter last checkup date here:",
             "Enter enclosure id:"]

data = []
message = Label(window, text="", font=("Consolas", 12), bg="#1e1e2e", fg="#c678dd")
message.pack(pady=5)

def submitFunction():
    global message, entry, data
    data = []
    flag = True
    for text in entry:
        if text.get() == "":
            flag = False
    
    if not flag:
        message.config(text="Enter Data Carefully !!!", fg="#e06c75")
    else:
        try:
            for inputField in entry:
                data.append(inputField.get())
            
            query.execute('''
            insert into animalRecords values(?,?,?,?,?,?,?,?,?,?,?)
            ''', (int(data[0]), data[1], data[2], data[3], data[4],
                  data[5], data[6], data[7], int(data[8]), data[9], int(data[10])))
            message.config(text="Data Submitted Successfully !!!", fg="#98c379")
            connect.commit()

            for inputField in entry:
                inputField.delete(0, END)

        except Exception as e:
            message.config(text=f"Error: {str(e)}", fg="#e06c75")

    window.after(5000, lambda: message.config(text=""))

mainFrame = Frame(window, bg="#1e1e2e")
mainFrame.pack(padx=5, pady=5, expand=True)

index = 0
for i in range(5):
    rowFrame = Frame(mainFrame, bg="#1e1e2e")
    rowFrame.pack(side="top", fill="x")

    for j in range(2):
        frame = Frame(rowFrame, width=350, height=70, bg="#282c34", borderwidth=2, relief="solid")
        frame.pack(side="left", padx=10, pady=1)
        frame.pack_propagate(False)

        label = Label(frame, text=labelText[index], bg="#282c34", fg="#61afef", font=("Consolas", 14, "bold"))
        label.pack(side="left")
        label.place(relx=0.1, rely=0.1)

        entry.append(Entry(frame, width=30, font=("Consolas", 12), bg="#3e4451", fg="#98c379", insertbackground="#c678dd"))
        entry[index].pack(side="left", padx=10)
        entry[index].place(relx=0.1, rely=0.5)
        index += 1

rowFrame = Frame(mainFrame, bg="#1e1e2e")
rowFrame.pack(side="top", fill="x")

frame = Frame(rowFrame, width=350, height=70, bg="#282c34", borderwidth=2, relief="solid")
frame.pack(side="left", padx=10, pady=1)
frame.pack_propagate(False)

label = Label(frame, text=labelText[index], bg="#282c34", fg="#61afef", font=("Consolas", 14, "bold"))
label.pack(side="left")
label.place(relx=0.1, rely=0.1)

entry.append(Entry(frame, width=30, font=("Consolas", 12), bg="#3e4451", fg="#98c379", insertbackground="#c678dd"))
entry[index].pack(side="left", padx=10)
entry[index].place(relx=0.1, rely=0.5)
index += 1

submitButton = Button(window, text="Submit", width=14, command=submitFunction,
                      bg="#3e4451", fg="#e5c07b", font=("Consolas", 12, "bold"), bd=2,
                      relief="raised", activebackground="#56b6c2", activeforeground="#1e1e2e")
submitButton.pack(pady=5)

query.execute('''
create table if not exists animalRecords(
    animalId int primary key,
    name text,
    species text,
    gender text check (gender in ("male", "female", "unknown")),
    dateOfBirth date,
    healthStatus text,
    diet text,
    arrivalDate date,
    keeperId int,
    lastCheckupDate date,
    enclosureId int,
    foreign key (enclosureId) references enclosureRecords(enclosureId),
    foreign key (keeperId) references staffRecords(staffId))
''')

connect.commit()
window.mainloop()
