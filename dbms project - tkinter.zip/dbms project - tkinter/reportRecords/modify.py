from tkinter import *
import sqlite3

window = Tk()
window.title("ZOO MANAGEMENT SYSTEM - OUTPUT")
window.geometry("800x550")
window.config(bg="#1e1e2e")

connect = sqlite3.connect("F:/my/be coding/dbms project - tkinter/zooDatabase.db")
query = connect.cursor()

message = Label(window, text="", font=("Consolas", 12), bg="#1e1e2e", fg="#c678dd")
message.pack(pady=5)

mainText = Label(window, text="ZOO MANAGEMENT SYSTEM", font=("Consolas", 28, "bold"), bg="#1e1e2e", fg="#c678dd")
mainText.pack(pady=5)

mainFrame = Frame(window, bg="#1e1e2e")
mainFrame.pack(expand=True, padx=10, pady=10)

button = []
info = ["Updation", "Deletion"]

attributes = ["reportId", "reportType", "generatedBy", "generatedDate", "reportDetails"]

value_entries = []
where_entries = []

def showMessage(msg, color="#e06c75"):
    message.config(text=msg, fg=color)
    window.after(5000, lambda: message.config(text=""))

def onClick(index):
    query_type = info[index]
    value_list = []
    where_list = []

    for i in range(len(attributes)):
        value_text = value_entries[index][i].get().strip()
        if index == 0:
            where_text = where_entries[index][i].get().strip()
        elif index == 1 and i == 0:
            where_text = where_entries[index][0].get().strip()
        else:
            where_text = ""

        if attributes[i] in ["reportId", "generatedBy"]:
            if value_text.isdigit():
                value_list.append(f"{attributes[i]}={int(value_text)}")
            if where_text.isdigit():
                where_list.append(f"{attributes[i]}={int(where_text)}")
        else:
            if value_text:
                value_list.append(f"{attributes[i]}='{value_text}'")
            if where_text:
                where_list.append(f"{attributes[i]}='{where_text}'")

    if not value_list and not where_list:
        showMessage("Enter Something First", "#e06c75")
        return

    try:
        if query_type == "Updation":
            if value_list and where_list:
                update_query = f"UPDATE reportRecords SET {', '.join(value_list)} WHERE {' AND '.join(where_list)};"
                query.execute(update_query)
                connect.commit()
                showMessage("Records Updated Successfully!", "#98c379")
            else:
                showMessage("Enter data for both SET and WHERE clause", "#e06c75")
        elif query_type == "Deletion":
            if where_list:
                delete_query = f"DELETE FROM reportRecords WHERE {' AND '.join(where_list)};"
                query.execute(delete_query)
                connect.commit()
                showMessage("Record Deleted Successfully!", "#98c379")
            else:
                showMessage("Enter data for WHERE clause in Deletion", "#e06c75")

    except sqlite3.Error as e:
        showMessage(f"Error: {str(e)}", "#e06c75")

    clearEntries(index)

def clearEntries(index):
    for i in range(len(attributes)):
        value_entries[index][i].delete(0, END)
        if index == 0:
            where_entries[index][i].delete(0, END)
    if index == 1:
        where_entries[index][0].delete(0, END)

index = 0
buttonIndex = 0
rowFrame = Frame(mainFrame, bg="#1e1e2e")
rowFrame.pack(side="top", fill="x")

for j in range(2):
    frame = Frame(rowFrame, width=350, height=400, bg="#282c34", borderwidth=2, relief="solid")
    frame.pack(side="left", padx=20, pady=5)
    frame.pack_propagate(False)

    label = Label(frame, text=info[index], bg="#282c34", fg="#61afef", font=("Consolas", 15, "bold"))
    label.place(relx=0.5, rely=0.05, anchor="center")

    innerFrame = Frame(frame, bg="#282c34")
    innerFrame.place(relx=0.5, rely=0.45, anchor="center")

    value_entries.append([])
    where_entries.append([])

    if j == 0:
        setLabel = Label(innerFrame, text="Set", font=("Consolas", 10, "bold"), bg="#282c34", fg="#e5c07b")
        setLabel.grid(row=0, column=1, padx=5, pady=2)
        whereLabel = Label(innerFrame, text="Where", font=("Consolas", 10, "bold"), bg="#282c34", fg="#e5c07b")
        whereLabel.grid(row=0, column=2, padx=5, pady=2)
    elif j == 1:
        whereLabel = Label(innerFrame, text="Where", font=("Consolas", 10, "bold"), bg="#282c34", fg="#e5c07b")
        whereLabel.grid(row=0, column=1, padx=5, pady=2)

    for k in range(len(attributes)):
        attrLabel = Label(innerFrame, text=attributes[k], font=("Consolas", 10), bg="#282c34", fg="#abb2bf")
        attrLabel.grid(row=k + 1, column=0, padx=5, pady=2)

        value_entry = Entry(innerFrame, width=15, font=("Consolas", 10), bg="#3e4451", fg="#98c379", insertbackground="#c678dd")
        value_entry.grid(row=k + 1, column=1, padx=5, pady=2)
        value_entries[index].append(value_entry)

        if j == 0:
            where_entry = Entry(innerFrame, width=15, font=("Consolas", 10), bg="#3e4451", fg="#98c379", insertbackground="#c678dd")
            where_entry.grid(row=k + 1, column=2, padx=5, pady=2)
            where_entries[index].append(where_entry)
        elif j == 1 and k == 0:
            where_entry = Entry(innerFrame, width=15, font=("Consolas", 10), bg="#3e4451", fg="#98c379", insertbackground="#c678dd")
            where_entry.grid(row=k + 1, column=1, padx=5, pady=2)
            where_entries[index].append(where_entry)

    buttonFrame = Frame(frame, bg="#282c34")
    buttonFrame.place(relx=0.5, rely=0.9, anchor="center")

    button.append(Button(buttonFrame, text="Submit", command=lambda i=buttonIndex: onClick(i), width=14,
                          bg="#3e4451", fg="#e5c07b", font=("Consolas", 10, "bold"), bd=2,
                          relief="raised", activebackground="#56b6c2", activeforeground="#1e1e2e"))
    button[buttonIndex].pack(side="left", padx=5)

    index += 1
    buttonIndex += 1

window.mainloop()
