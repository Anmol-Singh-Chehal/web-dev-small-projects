from tkinter import *
import sqlite3

window = Tk()
window.title("REPORT RECORDS - INPUT")
window.geometry("800x500")
window.config(bg="#1e1e2e")

connect = sqlite3.connect("F:/my/be coding/dbms project - tkinter/zooDatabase.db")
query = connect.cursor()

data = []
textArea = 0
entry = []
labelText = [
    "Enter report id here:",
    "Enter report type here:",
    "Enter generator staff id:",
    "Enter generated date here:",
    "Enter report details here:"
]

message = Label(window, text="", font=("Consolas", 12), bg="#1e1e2e", fg="#c678dd")
message.pack(pady=5)

def submitFunction():
    global message, entry, data
    data = []
    flag = True

    for text in entry:
        if text.get() == "":
            flag = False
    if textArea.get("1.0", "end-1c") == "":
        flag = False

    if not flag:
        message.config(text="Enter Data Carefully !!!", fg="#e06c75")
    else:
        try:
            for inputField in entry:
                data.append(inputField.get())
            data.append(textArea.get("1.0", "end-1c"))

            query.execute('''
                INSERT INTO reportRecords VALUES (?, ?, ?, ?, ?)
            ''', (int(data[0]), data[1], int(data[2]), data[3], data[4]))
            
            message.config(text="Data Submitted Successfully !!!", fg="#98c379")
            connect.commit()

            for inputField in entry:
                inputField.delete(0, END)
            textArea.delete("1.0", END)

        except Exception as e:
            message.config(text=f"Error: {str(e)}", fg="#e06c75")

    window.after(2000, lambda: message.config(text=" "))

mainFrame = Frame(window, bg="#1e1e2e")
mainFrame.pack(padx=5, pady=5)

index = 0
for i in range(2):
    rowFrame = Frame(mainFrame, bg="#1e1e2e")
    rowFrame.pack(side="top", fill="x")

    for j in range(2):
        frame = Frame(rowFrame, width=350, height=70, bg="#282c34", borderwidth=2, relief="solid")
        frame.pack(side="left", padx=10, pady=5)
        frame.pack_propagate(False)

        label = Label(frame, text=labelText[index], bg="#282c34", fg="#61afef", font=("Consolas", 14, "bold"))
        label.place(relx=0.04, rely=0.1)

        entry.append(Entry(frame, width=30, font=("Consolas", 12), bg="#3e4451", fg="#98c379", insertbackground="#c678dd"))
        entry[index].place(relx=0.04, rely=0.5)
        index += 1

textFrame = Frame(window, width=720, height=200, bg="#282c34", borderwidth=2, relief="solid")
textFrame.pack(pady=5)
textFrame.pack_propagate(False)

label = Label(textFrame, text=labelText[index], bg="#282c34", fg="#61afef", font=("Consolas", 14, "bold"))
label.place(relx=0.01, rely=0.02)

textArea = Text(textFrame, wrap="word", width=75, height=8, font=("Consolas", 12), bg="#3e4451", fg="#98c379", insertbackground="#c678dd", bd=0)
textArea.place(relx=0.01, rely=0.2)

textScrollbar = Scrollbar(textFrame, command=textArea.yview, bg="#3e4451")
textScrollbar.place(relx=0.97, rely=0.2, relheight=0.75)
textArea.config(yscrollcommand=textScrollbar.set)

submitButton = Button(window, text="Submit", width=14, command=submitFunction,
                      bg="#3e4451", fg="#e5c07b", font=("Consolas", 12, "bold"), bd=2,
                      relief="raised", activebackground="#56b6c2", activeforeground="#1e1e2e")
submitButton.pack(pady=10)

query.execute('''
    CREATE TABLE IF NOT EXISTS reportRecords (
        reportId INTEGER PRIMARY KEY,
        reportType TEXT,
        generatedBy INTEGER,
        generatedDate DATE,
        reportDetails TEXT,
        FOREIGN KEY (generatedBy) REFERENCES staffRecords(staffId)
    )
''')

connect.commit()
window.mainloop()
