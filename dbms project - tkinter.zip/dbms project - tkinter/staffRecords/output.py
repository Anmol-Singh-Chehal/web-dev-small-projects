from tkinter import *
import subprocess

window = Tk()
window.title("ZOO MANAGEMENT SYSTEM - OUTPUT")
window.geometry("800x500")
window.config(bg="#1e1e2e")

mainText = Label(window, text="ZOO MANAGEMENT SYSTEM", font=("Consolas", 28, "bold"), bg="#1e1e2e", fg="#c678dd")
mainText.pack(pady=10)

mainFrame = Frame(window, bg="#1e1e2e")
mainFrame.pack(expand=True, padx=10, pady=10)

button = []
info = ["Display Table", "Count Total Staff Members",
        "Count Each Member By Role", "Count and Sort By Hire Date", "Total Enclosure Assigned To Staff", "Staff To Enclosure Join"]
paths = ["F:/my/be coding/dbms project - tkinter/staffRecords/output/selectAll.py",
         "F:/my/be coding/dbms project - tkinter/staffRecords/output/count.py",
         "F:/my/be coding/dbms project - tkinter/staffRecords/output/countByRole.py",
         "F:/my/be coding/dbms project - tkinter/staffRecords/output/groupByHireDate.py",
         "F:/my/be coding/dbms project - tkinter/staffRecords/output/join1.py",
         "F:/my/be coding/dbms project - tkinter/staffRecords/output/join2.py"]

def onClick(index):
    subprocess.Popen(["python", paths[index]])

index = 0
buttonIndex = 0
for i in range(3):
    rowFrame = Frame(mainFrame, bg="#1e1e2e")
    rowFrame.pack(side="top", fill="x")
    for j in range(2):
        frame = Frame(rowFrame, width=350, height=120, bg="#282c34", borderwidth=2, relief="solid")
        frame.pack(side="left", padx=10, pady=5)
        frame.pack_propagate(False)

        label = Label(frame, text=info[index], bg="#282c34", fg="#61afef", font=("Consolas", 13, "bold"))
        label.place(relx=0.5, rely=0.3, anchor="center")

        buttonFrame = Frame(frame, bg="#282c34")
        buttonFrame.place(relx=0.5, rely=0.7, anchor="center")

        button.append(Button(buttonFrame, text="Show", command=lambda i=buttonIndex: onClick(i),
                              width=14, bg="#3e4451", fg="#98c379", font=("Consolas", 10, "bold"),
                              bd=2, relief="raised", activebackground="#56b6c2", activeforeground="#1e1e2e"))
        button[buttonIndex].pack(side="left", padx=5)
        index += 1
        buttonIndex += 1

window.mainloop()
