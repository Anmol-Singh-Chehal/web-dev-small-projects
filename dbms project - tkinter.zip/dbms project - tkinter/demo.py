import tkinter as tk

def close_app():
    root.destroy()

# Create main window
root = tk.Tk()
root.overrideredirect(True)  # Remove native title bar
root.geometry("400x300")

# Custom title bar frame
title_bar = tk.Frame(root, bg="blue", relief="raised", bd=2)
title_bar.pack(side="top", fill="x")

# Add title label
title_label = tk.Label(title_bar, text="Custom Title Bar", bg="blue", fg="white")
title_label.pack(side="left", padx=10)

# Add close button
close_button = tk.Button(title_bar, text="X", bg="red", fg="white", command=close_app)
close_button.pack(side="right")


def start_move(event):
    root.x = event.x
    root.y = event.y

def move_window(event):
    x = root.winfo_pointerx() - root.x
    y = root.winfo_pointery() - root.y
    root.geometry(f"+{x}+{y}")

title_bar.bind("<Button-1>", start_move)
title_bar.bind("<B1-Motion>", move_window)

# Run the application
root.mainloop()
